package com.TasksManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasksManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
